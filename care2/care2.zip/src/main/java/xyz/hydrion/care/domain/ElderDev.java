package xyz.hydrion.care.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import xyz.hydrion.care.domain.form.DevForm;

import java.sql.Timestamp;
import java.util.List;

public class ElderDev {
    Integer id;
    @JsonProperty("wearer_name")
    String wearerName;
    @JsonProperty("create_time")
    Timestamp createTime;

    public ElderDev(){

    }

    public ElderDev(DevForm form) {
        this.id = form.getDevId();
        this.wearerName = form.getWearerName();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getWearerName() {
        return wearerName;
    }

    public void setWearerName(String wearerName) {
        this.wearerName = wearerName;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }
}
