package xyz.hydrion.care.domain.form;

import javax.validation.constraints.*;

public class DevForm {

    @NotEmpty(message = "设备id不能为空")
    @Max(value = 9999, message = "id范围：1-9999")
    @Min(value = 1, message = "id范围：1-9999")
    Integer devId;
    @NotEmpty(message = "穿戴者称呼不能为空")
    String wearerName;

    public Integer getDevId() {
        return devId;
    }

    public void setDevId(Integer devId) {
        this.devId = devId;
    }

    public String getWearerName() {
        return wearerName;
    }

    public void setWearerName(String wearerName) {
        this.wearerName = wearerName;
    }
}
